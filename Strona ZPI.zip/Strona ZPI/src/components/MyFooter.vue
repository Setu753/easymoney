<template>
  <footer class="footer">
    <div class="footer__wave"></div>
    <section class="footer__group">
      <div class="footer__container container">
        <div class="footer__item">
          <h3 class="footer__title">
            <span class="footer__stripe stripe">Milu</span>
          </h3>
          <p class="footer__description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam, quis nostrud exercitationt.
          </p>
        </div>
        <div class="footer__item">
          <h3 class="footer__title">QuickLinks</h3>
          <ul class="footer__menu">
            <li class="footer__menu__item">
              <a class="footer__link">About US</a>
            </li>
            <li class="footer__menu__item">
              <a class="footer__link">FAQ</a>
            </li>
            <li class="footer__menu__item">
              <a class="footer__link">Blog</a>
            </li>
            <li class="footer__menu__item">
              <a class="footer__link">Contact Us</a>
            </li>
          </ul>
        </div>
        <div class="footer__item">
          <h3 class="footer__title">Last Tweet</h3>
          <a class="twitter">
            <p class="twitter__date footer__description">about 2 months ago</p>
            <p class="footer__description">
              Finally a new theme! Check out ‘Craftz - A wordPress Theme for
              Small Business Owners’
            </p>
          </a>
        </div>
        <div class="footer__item">
          <h3 class="footer__title">Download Our App</h3>
          <p class="footer__market footer__description">
            Available on Google Play and App Store.
          </p>
          <div class="market">
            <a class="market__link">
              <img
                class="market__image"
                src="assets/googleplay.png"
                alt="Google Play Icon"
              />
            </a>
            <a class="market__link">
              <img
                class="market__image"
                src="assets/appstore.png"
                alt="App Store Icon"
              />
            </a>
          </div>
          <div class="social">
            <a class="social__link">
              <img
                class="social__image"
                src="assets/icon-facebook.png"
                alt="Facebook Icon"
              />
            </a>
            <a class="social__link">
              <img
                class="social__image"
                src="assets/icon-twitter.png"
                alt="Twitter Icon"
              />
            </a>
            <a class="social__link">
              <img
                class="social__image"
                src="assets/icon-instagram.png"
                alt="Instagram Icon"
              />
            </a>
          </div>
        </div>
      </div>
    </section>
  </footer>
</template>
<script>
export default {
  name: "MyFooter",
};
</script>
