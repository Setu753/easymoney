<template>
  <header class="header">
    <div class="header__container container">
      <div class="header__group">
        <a class="header__logo">
          <img class="header__image" src="assets/logo.png" alt="Company Logo" />
        </a>
        <ul class="header__menu">
          <li class="header__item">
            <a class="header__link header__link--active">home</a>
          </li>
          <li class="header__item">
            <a class="header__link">pages</a>
          </li>
          <li class="header__item">
            <a class="header__link">portfolio</a>
          </li>
          <li class="header__item">
            <a class="header__link">shop</a>
          </li>
          <li class="header__item">
            <a class="header__link">blog</a>
          </li>
          <li class="header__item">
            <a class="header__link">element</a>
          </li>
        </ul>
      </div>
      <a class="header__button button">start now</a>
      <button class="header__menu-button">
        <img src="assets/icon-menu.png" alt="Mobile Menu" />
      </button>
    </div>
  </header>
</template>
<script>
export default {
  name: "HeaderNav",
};
</script>
