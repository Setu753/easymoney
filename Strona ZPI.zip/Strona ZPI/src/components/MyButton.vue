<template>
  <a :class="['hero__button', 'button', variant, size]">{{ label }}</a>
</template>
<script>
export default {
  name: "MyButton",
  props: {
    label: String,
    size: { type: String, default: "--medium" },
    variant: { type: String, default: "primary" },
  },
};
</script>
<style lang="scss">
.button {
  padding: 16px 32px;
  border: 0;
  border-radius: 24px;
  font-size: 12px;
  line-height: 16px;
  font-weight: bold;
  display: inline-block;
  text-transform: uppercase;
  color: white;
  text-align: center;
  cursor: pointer;

  &.primary {
    background-image: linear-gradient(to right, #828fd3, #5e6dbe 51%, #5461aa);
  }

  &.primary:hover {
    box-shadow: 0 16px 32px 0 rgba(0, 0, 0, 0.16);
    background-image: linear-gradient(to right, #5e6dbe, #5967b5 51%, #5461ab);
    transform: translate(0, -2px);
  }

  &.--medium {
    padding: 14px 26px;
  }

  &.--large {
    padding: 16px 32px;
  }
}
</style>
