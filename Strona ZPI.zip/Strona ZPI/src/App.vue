<template>
  <header-nav />
  <RouterView />
  <my-footer />
</template>
<script>
import HeaderNav from "./components/HeaderNav.vue";
import MyFooter from "./components/MyFooter.vue";

export default {
  name: "App",
  components: {
    HeaderNav,
    MyFooter,
  },
};
</script>
