<template>
  <main class="main">
    <section class="hero hero--wave">
      <div class="hero__container container">
        <div class="hero__column column">
          <div class="hero__content">
            <h1 class="hero__title title">
              We Build <br />
              <span class="hero__stripe stripe">Mobile</span> App
            </h1>
            <p class="hero__description description">
              Lorem ipsum dolor sit amet, conse ctetuer adipiscing elit, sed
              diam nonum nibhie euismod.
            </p>
            <div class="hero__buttons">
              <my-button label="learn more" />
              <!-- <a class="hero__button button button--primary">learn more</a> -->
              <a class="hero__button button button--secondary">contact us</a>
            </div>
          </div>
        </div>
        <div class="hero__column column">
          <img
            class="column--image"
            src="assets/hero.png"
            alt="Employees are talking about dashboard design"
          />
        </div>
      </div>
    </section>
    <section class="cliparts">
      <div class="clipart__container container">
        <div class="clipart__item">
          <img
            class="clipart__image"
            src="assets/clipart-1.png"
            alt="Creative Ideas"
          />
          <h3 class="clipart__title title">Creative Ideas</h3>
          <p class="clipart__description description">
            Duis vel nibh at velit scelerisque suscipit. Curabitur ligula
            sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
          </p>
        </div>
        <div class="clipart__item">
          <img
            class="clipart__image"
            src="assets/clipart-2.png"
            alt="Innovative Tools"
          />
          <h3 class="clipart__title title">Innovative Tools</h3>
          <p class="clipart__description description">
            Duis vel nibh at velit scelerisque suscipit. Curabitur ligula
            sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
          </p>
        </div>
        <div class="clipart__item">
          <img
            class="clipart__image"
            src="assets/clipart-3.png"
            alt="Performance Optimized"
          />
          <h3 class="clipart__title title">Performance Optimized</h3>
          <p class="clipart__description description">
            Duis vel nibh at velit scelerisque suscipit. Curabitur ligula
            sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
          </p>
        </div>
        <div class="clipart__item">
          <img
            class="clipart__image"
            src="assets/clipart-4.png"
            alt="Goal Achievement"
          />
          <h3 class="clipart__title title">Goal Achievement</h3>
          <p class="clipart__description description">
            Duis vel nibh at velit scelerisque suscipit. Curabitur ligula
            sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
          </p>
        </div>
      </div>
    </section>
    <section class="tile">
      <div class="tile__container container">
        <div class="column column--centered">
          <div class="tile__content">
            <h2 class="tile__title title">
              App
              <span class="stripe">Development</span>
            </h2>
            <p class="tile__description description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.
            </p>
            <a class="button button--primary">learn more</a>
          </div>
        </div>
        <div class="tile__image column column--centered">
          <img
            class="column--image"
            src="assets/section-1.png"
            alt="Employees are talking about mobile app development"
          />
        </div>
      </div>
    </section>
    <section class="tile">
      <div class="tile__container tile--reversed container">
        <div class="column column--centered">
          <div class="tile__content">
            <h2 class="tile__title title">
              <span class="stripe">E-Commerce</span>
              Plan
            </h2>
            <p class="tile__description description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.
            </p>
            <a class="button button--primary">learn more</a>
          </div>
        </div>
        <div class="tile__image column column--centered">
          <img
            class="column--image"
            src="assets/section-2.png"
            alt="Employee is thinking about online shop user experience"
          />
        </div>
      </div>
    </section>
    <section class="business tile">
      <div class="business__container container">
        <div class="business__column column">
          <div class="tile__content">
            <h2 class="tile__title title">
              What
              <span class="stripe">We Do</span>
            </h2>
            <p class="tile__description description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.
            </p>
            <a class="button button--primary">learn more</a>
          </div>
        </div>
        <div class="business__column column">
          <div class="business__group">
            <div class="business__item">
              <div class="business__icon business__icon--secondary">
                <img
                  class="business__image"
                  src="assets/icon-stack.png"
                  alt="Stack Icon"
                />
              </div>
              <div class="business__content">
                <h3 class="business__title title">Data Analysis</h3>
                <p class="business__description description">
                  Praesent nonummy mi in odio. Mauris sollicitudin fermentum
                  libero.
                </p>
              </div>
            </div>
            <div class="business__item">
              <div class="business__icon business__icon--primary">
                <img
                  class="business__image"
                  src="assets/icon-heart.png"
                  alt="Heart Icon"
                />
              </div>
              <div class="business__content">
                <h3 class="business__title title">Engaging Content</h3>
                <p class="business__description description">
                  Praesent nonummy mi in odio. Mauris sollicitudin fermentum
                  libero.
                </p>
              </div>
            </div>
            <div class="business__item">
              <div class="business__icon business__icon--primary">
                <img
                  class="business__image"
                  src="assets/icon-graph-pie.png"
                  alt="Pie Graph Icon"
                />
              </div>
              <div class="business__content">
                <h3 class="business__title title">Web Expertise</h3>
                <p class="business__description description">
                  Praesent nonummy mi in odio. Mauris sollicitudin fermentum
                  libero.
                </p>
              </div>
            </div>
            <div class="business__item">
              <div class="business__icon business__icon--secondary">
                <img
                  class="business__image"
                  src="assets/icon-stack.png"
                  alt="Stack Icon"
                />
              </div>
              <div class="business__content">
                <h3 class="business__title title">App Development</h3>
                <p class="business__description description">
                  Praesent nonummy mi in odio. Mauris sollicitudin fermentum
                  libero.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="parallax parallax--one"></div>
    <section class="tile">
      <div class="tile__container container">
        <div class="column column--centered">
          <div class="progress tile__content">
            <h2 class="tile__title title">
              Innovative
              <span class="stripe">Mobile</span>
              UI
            </h2>
            <div class="progress__group">
              <div class="progress__item">
                <div class="progress__title title">
                  <span>Development</span>
                  <span>90%</span>
                </div>
                <div class="progress__bar">
                  <div
                    class="progress__bar--filled progress__bar--secondary progress--90"
                  ></div>
                </div>
              </div>
              <div class="progress__item">
                <div class="progress__title title">
                  <span>Design</span>
                  <span>80%</span>
                </div>
                <div class="progress__bar">
                  <div
                    class="progress__bar--filled progress__bar--primary progress--80"
                  ></div>
                </div>
              </div>
              <div class="progress__item">
                <div class="progress__title title">
                  <span>Marketing</span>
                  <span>70%</span>
                </div>
                <div class="progress__bar">
                  <div
                    class="progress__bar--filled progress__bar--secondary progress--70"
                  ></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tile__image column column--centered">
          <img
            class="column--image"
            src="assets/section-3.png"
            alt="Example system statistics"
          />
        </div>
      </div>
    </section>
    <section class="articles tile">
      <div class="articles__container container">
        <div class="article__item">
          <div class="article__group">
            <img
              class="article__image"
              src="assets/image-1.png"
              alt="Knowledge gathering"
            />
          </div>
          <h3 class="article__title title">Hello world!</h3>
          <p class="article__info description">
            <span>April 29, 2019</span> • <span>standard</span>
          </p>
          <p class="article__description description">
            Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero,
            non adipiscing dolor urna a orci. Fusce commodo aliquam arcu. In ac
            felis...
          </p>
          <a class="article__link">read more</a>
        </div>
        <div class="article__item">
          <div class="article__group">
            <img
              class="article__image"
              src="assets/image-2.png"
              alt="Bitcoin information sharing"
            />
          </div>
          <h3 class="article__title title">The Blue Night</h3>
          <p class="article__info description">
            <span>May 2, 2019</span> • <span>Ferdinand Davidson</span>
          </p>
          <p class="article__description description">
            Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero,
            non adipiscing dolor urna a orci. Fusce commodo aliquam arcu. In ac
            felis...
          </p>
          <a class="article__link">read more</a>
        </div>
        <div class="article__item">
          <div class="article__group">
            <img
              class="article__image"
              src="assets/image-3.png"
              alt="Media management"
            />
          </div>
          <h3 class="article__title title">Image</h3>
          <p class="article__info description">
            <span>May 3, 2019</span> • <span>Ferdinand Davidson</span>
          </p>
          <p class="article__description description">
            Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero,
            non adipiscing dolor urna a orci. Fusce commodo aliquam arcu. In ac
            felis...
          </p>
          <a class="article__link">read more</a>
        </div>
      </div>
    </section>
    <div class="parallax parallax--two"></div>
    <section class="tile">
      <div class="contact tile__container container">
        <div class="column">
          <div class="contact__content tile__content">
            <h2 class="tile__title title">
              What Set Us
              <span class="stripe">Apart</span>
            </h2>
            <p class="tile__description description">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat.
            </p>
            <div class="contact__group">
              <div class="contact__item">
                <h3 class="contact__title title">Address</h3>
                <p class="contact__description description">78 Ohio Dr.</p>
                <p class="contact__description description">
                  Patchogue, NY 11772
                </p>
              </div>
              <div class="contact__item">
                <h3 class="contact__title title">Working Hours</h3>
                <p class="contact__description description">
                  Monday to Friday: 9AM - 8PM
                </p>
                <p class="contact__description description">
                  Week-End: 10AM - 5PM
                </p>
              </div>
              <div class="contact__item">
                <h3 class="contact__title title">Contact</h3>
                <p class="contact__description description">email@milu.com</p>
                <p class="contact__description description">
                  +88 (0) 101 0000 000
                </p>
              </div>
              <div class="contact__item">
                <h3 class="contact__title title">Socials</h3>
                <div class="contact__socials">
                  <a class="contact__social">
                    <img
                      class="contact__image"
                      src="assets/icon-facebook.png"
                      alt="Facebook Icon"
                    />
                  </a>
                  <a class="contact__social">
                    <img
                      class="contact__image"
                      src="assets/icon-twitter.png"
                      alt="Twitter Icon"
                    />
                  </a>
                  <a class="contact__social">
                    <img
                      class="contact__image"
                      src="assets/icon-instagram.png"
                      alt="Instagram Icon"
                    />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="column">
          <div class="form tile__content">
            <h2 class="tile__title title">Get In Touch</h2>
            <form class="form__group">
              <div class="form__row form__row--double">
                <input
                  class="form__input form__input--50"
                  type="text"
                  name="name"
                  placeholder="Your Name"
                />
                <input
                  class="form__input form__input--50"
                  type="text"
                  name="e-mail"
                  placeholder="Your Email"
                />
              </div>
              <div class="form__row">
                <input
                  class="form__input"
                  type="text"
                  name="title"
                  placeholder="Title"
                />
              </div>
              <div class="form__row">
                <textarea
                  class="form__input form__input--textarea"
                  rows="5"
                  name="message"
                  placeholder="Message"
                ></textarea>
              </div>
              <button class="form__button button button--primary">send</button>
            </form>
          </div>
        </div>
      </div>
    </section>
  </main>
</template>
<script>
import MyButton from "../components/MyButton.vue";

export default {
  name: "HomeView",
  components: {
    MyButton,
  },
};
</script>
